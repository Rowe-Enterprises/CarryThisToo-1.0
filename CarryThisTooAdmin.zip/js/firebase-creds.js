// Initialize Firebase
var config = {
    apiKey: "AIzaSyAFmbwgaEXTtlY5KEc_XRIlI8PiPbE6iYE",
    authDomain: "carry-this-too-1.firebaseapp.com",
    databaseURL: "https://carry-this-too-1.firebaseio.com",
    projectId: "carry-this-too-1",
    storageBucket: "carry-this-too-1.appspot.com",
    messagingSenderId: "534635995761"
};
